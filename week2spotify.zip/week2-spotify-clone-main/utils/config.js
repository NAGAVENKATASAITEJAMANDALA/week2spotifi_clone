export const backendUrl = "http://localhost:8000";
export const cloudinary_upload_preset = "nitinborase";